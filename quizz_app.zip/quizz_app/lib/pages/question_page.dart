import 'package:flutter/material.dart';
import 'package:quizz_app/customwidgets/question_set_widget.dart';
import 'package:quizz_app/pages/result_page.dart';
import 'package:quizz_app/temp_db.dart';

class QuestionPage extends StatefulWidget {
  static const String routeName = '/';
  const QuestionPage({Key? key}) : super(key: key);

  @override
  State<QuestionPage> createState() => _QuestionPageState();
}

class _QuestionPageState extends State<QuestionPage> {
  String groupValue = '';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter Quiz'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pushNamed(context, ResultPage.routeName),
            child: const Text('FINISH', style: TextStyle(color: Colors.white),),
          )
        ],
      ),
      body: ListView.builder(
        itemCount: questionList.length,
        itemBuilder: (context, index) {
          final ques = questionList[index];
          return QuestionSetView(
            q: ques,
            index: index,
            onAnswered: (value) {
              questionList[index][givenAnswer] = value;
            },
          );
        },
      ),
    );
  }
}
